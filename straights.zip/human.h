#ifndef __HUMAN_H_
#define __HUMAN_H_
#include "player.h"

class Human : public Player { 
	public:
	Human(); 
	bool humanType(); 
};

#endif
