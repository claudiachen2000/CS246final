#include "human.h"

Human::Human(): Player{} {}

bool Human::humanType() {
    return true;
}
